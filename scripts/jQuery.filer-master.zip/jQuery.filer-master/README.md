# jQuery.filer was transferred to <a href="https://innostudio.de/fileuploader/"><b>Fileuploader</b></a>

Get the old jQuery.filer docs <a href="http://filer.grandesign.md/old_version" target="_blank">here</a>.<br><br>
<a href="https://innostudio.de/fileuploader/"><img src="http://innostudio.de/fileuploader/preview2.jpg?v=1.3"></a>
